const header = document.querySelector("#page-header");
let img = document.createElement("img")
let btn = document.createElement("button");
header.style.position = 'relative';

img.src = "https://i.imgur.com/fJY6SDB.png";
img.style.width = '50px';
img.style.height = '50px';

btn.style.backgroundColor = '#9763f6';

btn.style.position = 'absolute';
btn.style.display = 'flex';
btn.style.alignItems = 'center';
btn.style.justifyContent = 'center';
btn.style.top = '1px';
btn.style.right = '1px';
btn.style.width = '60px';
btn.style.height = '60px';
btn.style.border = '4px solid #9763f6';
btn.style.borderRadius = '50%';
btn.style.color = 'white';

btn.appendChild(img);

const print = function(){
	const radios = document.querySelectorAll('input');
	radios.forEach(r=>r.style.display = 'none');

	const icones = document.querySelectorAll('i.icon');
	icones.forEach(i=>i.style.display = 'none');

	const feedback = document.querySelectorAll('.content .outcome');
	feedback.forEach(f=>f.style.display = 'none');

	const info = document.querySelectorAll('.info');
	info.forEach(f=>f.style.display = 'none');

	document.querySelector('.quizreviewsummary').style.display = 'none';
	document.querySelector('.activity-navigation').style.display = 'none';
	document.querySelector('#top-footer').style.display = 'none';
	document.querySelector('#page-header div').style.display = 'none';
btn.style.display = 'none';


	window.print();
	location.reload();
}


btn.addEventListener('click',print);
header.appendChild(btn);


